console.log("OSS image bed kernel entry loaded.");
